Lady D - October 20, 2026 author edition

Start with susan-damon-hub.html. The books remain under downloads/lady-d-finalization/, matching the website directory structure. Artwork, fonts, and online-book controls are bundled.

This smaller web review package includes the online books, gallery, covers, and narration manifests. PDF and ZIP links open the current website and require internet.

Payment links and the separate motion demonstration require internet. No audio has been generated. Author review and final printed proof remain the next publishing steps.

Author commentary follows the October vocabulary direction. Exact Bible quotations retain their wording. Historical audit material in production/ documents earlier wording.
